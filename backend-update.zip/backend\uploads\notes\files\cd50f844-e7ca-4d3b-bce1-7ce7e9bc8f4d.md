# 前缀和与差分（离散化）学习笔记

## 1. 核心概念速览

| 操作 | 场景 | 时间复杂度 | 核心思想 |
|------|------|-----------|--------|
| **前缀和查询** | 多次区间求和 | 预处理 $O(n)$ + 查询 $O(1)$ | 预先累加，查询用差分 |
| **差分修改** | 多次区间修改 | 预处理 $O(n)$ + 修改 $O(1)$ + 还原 $O(n)$ | 修改端点，最后前缀和还原 |
| **离散化** | 坐标很大或很稀疏 | 预处理 $O(n \log n)$ | 坐标映射+前缀和 |

---

## 2. 一维前缀和

### 定义
设 `s[i]` 表示 `a[1] + a[2] + ... + a[i]`，约定 `s[0] = 0`。

### 区间和公式
$$\text{sum}(l, r) = s[r] - s[l-1]$$

### 模板代码
```cpp
#include <iostream>
using namespace std;

const int N = 1000010;
int a[N];
long long s[N];

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    // 构建前缀和
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        s[i] = s[i - 1] + a[i];
    }

    // 多次查询
    while (m--) {
        int l, r;
        cin >> l >> r;
        cout << (s[r] - s[l - 1]) << '\n';
    }

    return 0;
}
```

### 易错点
1. 下标从 1 开始，`s[0] = 0`（全局数组默认初始化为 0）
2. 公式是 `s[r] - s[l - 1]`，不是 `s[r] - s[l]`
3. 当数据范围较大时，`s` 数组用 `long long`

---

## 3. 二维前缀和

### 定义
`s[i][j]` 表示从 `(1,1)` 到 `(i,j)` 的子矩阵所有元素之和。

### 状态转移（容斥原理）
$$s[i][j] = s[i-1][j] + s[i][j-1] - s[i-1][j-1] + a[i][j]$$

### 子矩阵和公式
查询从 `(x1,y1)` 到 `(x2,y2)` 的子矩阵和：
$$\text{sum} = s[x2][y2] - s[x1-1][y2] - s[x2][y1-1] + s[x1-1][y1-1]$$

### 模板代码
```cpp
#include <iostream>
using namespace std;

const int N = 1010;
int a[N][N];
long long s[N][N];

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m, q;
    cin >> n >> m >> q;

    // 构建二维前缀和
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cin >> a[i][j];
            // 容斥：加当前，减重复的两部分，再加左上角
            s[i][j] = s[i - 1][j] + s[i][j - 1] - s[i - 1][j - 1] + a[i][j];
        }
    }

    // 多次查询
    while (q--) {
        int x1, y1, x2, y2;
        cin >> x1 >> y1 >> x2 >> y2;
        long long ans = s[x2][y2] - s[x1 - 1][y2] - s[x2][y1 - 1] + s[x1 - 1][y1 - 1];
        cout << ans << '\n';
    }

    return 0;
}
```

### 易错点
1. 容斥公式容易漏掉 `+ s[x1-1][y1-1]`
2. 所有下标都从 1 开始
3. 前缀和数组用 `long long`

---

## 4. 一维差分

### 场景
**多次区间修改，最后统一查询结果**

给定数组，需要多次执行 `[l,r] += x`，最后输出修改后的数组。

### 核心思想
- 直接修改 `O(1)` 而不是遍历 `O(n)`
- 最后一次扫描用前缀和还原

### 差分数组定义
```
b[1] = a[1]
b[i] = a[i] - a[i-1]  (i >= 2)
```

还原：`a[i] = b[1] + b[2] + ... + b[i]`

### 区间修改操作
给 `[l, r]` 都加 `x`：
```
b[l] += x
b[r+1] -= x
```

### 模板代码
```cpp
#include <iostream>
using namespace std;

const int N = 1000010;
int n, m;
long long a[N], b[N];

// 给 [l, r] 加 val
void addRange(int l, int r, long long val) {
    b[l] += val;
    if (r + 1 <= n) {
        b[r + 1] -= val;
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n >> m;

    // 初始化差分数组
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        addRange(i, i, a[i]);
    }

    // m 次区间修改
    while (m--) {
        int l, r;
        long long x;
        cin >> l >> r >> x;
        addRange(l, r, x);
    }

    // 最后一次扫描还原答案（前缀和）
    for (int i = 1; i <= n; i++) {
        b[i] += b[i - 1];
        cout << b[i] << (i == n ? '\n' : ' ');
    }

    return 0;
}
```

### 易错点
1. 修改时要检查 `r+1 <= n`，避免越界
2. 最后要做前缀和还原，不能只输出 `b` 数组
3. 所有数组用 `long long` 防止溢出

---

## 5. 二维差分

### 场景
**多次子矩阵修改，最后统一查询结果**

给定矩阵，需要多次执行 "给子矩阵 `[x1,y1]~[x2,y2]` 加 `c`"，最后输出修改后的矩阵。

### 核心思想（容斥）
要给子矩阵加值，只需修改四个角：
```
b[x1][y1] += c        // 左上
b[x1][y2+1] -= c      // 右上（会抵消右边）
b[x2+1][y1] -= c      // 左下（会抵消下边）
b[x2+1][y2+1] += c    // 右下（会再加回）
```

### 还原方式（二维前缀和）
```cpp
for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= m; j++) {
        b[i][j] += b[i - 1][j] + b[i][j - 1] - b[i - 1][j - 1];
    }
}
```

### 模板代码
```cpp
#include <iostream>
using namespace std;

const int N = 1010;
int n, m, q;
long long a[N][N], b[N][N];

// 给子矩阵 [x1,y1]~[x2,y2] 加 c
void insert(int x1, int y1, int x2, int y2, long long c) {
    b[x1][y1] += c;
    b[x1][y2 + 1] -= c;
    b[x2 + 1][y1] -= c;
    b[x2 + 1][y2 + 1] += c;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n >> m >> q;

    // 初始化差分矩阵
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cin >> a[i][j];
            insert(i, j, i, j, a[i][j]);
        }
    }

    // q 次子矩阵修改
    while (q--) {
        int x1, y1, x2, y2;
        long long c;
        cin >> x1 >> y1 >> x2 >> y2 >> c;
        insert(x1, y1, x2, y2, c);
    }

    // 最后还原（二维前缀和）
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            b[i][j] += b[i - 1][j] + b[i][j - 1] - b[i - 1][j - 1];
            cout << b[i][j] << (j == m ? '\n' : ' ');
        }
    }

    return 0;
}
```

### 易错点
1. 四个角都要处理：左上加，右上减，左下减，右下加（容斥）
2. 修改时要检查边界 `x2+1 <= n+1` 等
3. 还原用的是**二维前缀和**，不是一维
4. 所有数组用 `long long`

---

## 6. 离散化前缀和

### 场景
坐标范围很大（$10^9$），但坐标数量很少，不能直接开数组。

**需要**：
- `n` 次单点加法：在坐标 `x` 处加上 `c`
- `m` 次区间查询：查询 `[l,r]` 的总和

### 解决思路
1. 收集所有坐标到 `alls` 数组
2. 排序 + 去重
3. 用二分查找把原坐标映射到离散下标
4. 在离散坐标上执行前缀和操作

### 完整模板
```cpp
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

typedef long long LL;
const int N = 300010;

int n, m;
int a[N];               // a[i] = 离散坐标 i 处的值
LL s[N];                // 前缀和
vector<int> alls;       // 所有出现过的坐标

int findIndex(int x) {
    // 找 x 在 alls 中的位置（1-based）
    return lower_bound(alls.begin(), alls.end(), x) - alls.begin() + 1;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    cin >> n >> m;

    // 第一遍：读操作，收集坐标
    vector<pair<int, int>> addOps;    // {坐标, 增加量}
    vector<pair<int, int>> queries;   // {左端点, 右端点}

    for (int i = 0; i < n; i++) {
        int x, c;
        cin >> x >> c;
        addOps.push_back({x, c});
        alls.push_back(x);
    }

    for (int i = 0; i < m; i++) {
        int l, r;
        cin >> l >> r;
        queries.push_back({l, r});
        alls.push_back(l);
        alls.push_back(r);
    }

    // 排序 + 去重
    sort(alls.begin(), alls.end());
    alls.erase(unique(alls.begin(), alls.end()), alls.end());

    // 第二遍：处理单点加法
    for (auto [x, c] : addOps) {
        int idx = findIndex(x);
        a[idx] += c;
    }

    // 构建前缀和
    for (int i = 1; i <= alls.size(); i++) {
        s[i] = s[i - 1] + a[i];
    }

    // 处理查询
    for (auto [l, r] : queries) {
        int li = findIndex(l);
        int ri = findIndex(r);
        cout << s[ri] - s[li - 1] << '\n';
    }

    return 0;
}
```

### 关键细节
- `findIndex()` 用 `lower_bound` 找第一个 `>= x` 的位置，再 `+1` 转成 1-based
- `a` 表示每个离散坐标处的原始值
- `s` 独立构建，不要把 `a` 改成前缀和
- 查询时坐标映射要一致

### 复杂度
- 收集坐标：$O((n+m) \log(n+m))$（排序）
- 处理操作：$O(n + m)$
- 总计：$O((n+m) \log(n+m))$

---

## 7. 对比总结表

| 技巧 | 用途 | 预处理 | 单次操作 | 适用场景 |
|------|------|--------|---------|---------|
| **前缀和** | 区间求和 | $O(n)$ | 查询 $O(1)$ | 静态数组，多次查询 |
| **差分** | 区间修改 | $O(n)$ | 修改 $O(1)$ | 多次修改，最后查询 |
| **2D 前缀和** | 子矩阵求和 | $O(nm)$ | 查询 $O(1)$ | 静态矩阵，多次查询 |
| **2D 差分** | 子矩阵修改 | $O(nm)$ | 修改 $O(1)$ | 多次修改，最后查询 |
| **离散化** | 稀疏坐标 | $O(n \log n)$ | $O(\log n)$ | 坐标范围大但数量少 |

---

## 8. 选择指南

```
问题分析：
├─ 多次「区间求和」？
│  ├─ 坐标稀疏？→ 离散化 + 前缀和
│  └─ 坐标连续？→ 直接前缀和（1D 或 2D）
│
├─ 多次「区间修改」？
│  ├─ 矩阵修改？→ 2D 差分
│  └─ 数组修改？→ 1D 差分
│
└─ 既有修改又有查询？
   ├─ 修改多，查询少？→ 差分（最后一次查询）
   ├─ 修改少，查询多？→ 考虑分块或树状数组
   └─ 都差不多？→ 考虑树状数组或线段树
```

---

## 9. 推荐学习路径

1. ✓ 先掌握**一维前缀和**（最简单）
2. ✓ 再学**二维前缀和**（容斥原理）
3. ✓ 再学**一维差分**（反向思维）
4. ✓ 再学**二维差分**（2D 容斥）
5. ✓ 最后学**离散化**（坐标映射）
6. 进阶：分块、树状数组、线段树等高级数据结构

